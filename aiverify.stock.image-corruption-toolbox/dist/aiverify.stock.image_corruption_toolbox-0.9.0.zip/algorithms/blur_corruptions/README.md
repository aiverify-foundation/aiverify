# Algorithm - Blur Corruptions

## Description
* Robustness plugin with blur corruptions

## License
* Licensed under Apache Software License 2.0

## Plugin URL
* https://pypi.org/project/example_plugin/

## Developers:
* AI Verify

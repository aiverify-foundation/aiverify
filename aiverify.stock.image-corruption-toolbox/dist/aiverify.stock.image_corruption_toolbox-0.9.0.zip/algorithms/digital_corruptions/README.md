# Algorithm - Digital Corruptions

## Description
* Robustness plugin for digital corruptions

## License
* Licensed under Apache Software License 2.0

## Plugin URL
* https://gitlab.com/imda_dsl/t2po/ai-verify/ai-verify-stock-plugins/aiverify.stock.image-corruption-toolbox

## Developers:
* AI Verify

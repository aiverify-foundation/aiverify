# Test Engine Core

## Description
* This core project will support critical functionalities to support plugins and apps.

## License
* Licensed under Apache Software License 2.0

## Developers:
* AI Verify
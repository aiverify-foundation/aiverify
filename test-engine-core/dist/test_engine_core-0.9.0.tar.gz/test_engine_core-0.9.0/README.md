# Test Engine Core

## Description
* This core project will support critical functionalities to support plugins and apps.

## License
* Licensed under Apache Software License 2.0

## Plugin URL
* https://gitlab.com/imda_dsl/t2po/ai-verify/ai-verify-test-engine/test-engine-core

## Developers:
* AI Verify
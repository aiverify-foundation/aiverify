# Algorithm - Digital Corruptions

## Description
* Robustness plugin for digital corruptions

## License
* Licensed under Apache Software License 2.0

## Developers:
* AI Verify

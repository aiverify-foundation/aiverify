# Algorithm - Blur Corruptions

## Description
* Robustness plugin with blur corruptions

## License
* Licensed under Apache Software License 2.0

## Developers:
* AI Verify

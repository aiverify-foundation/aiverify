# AI Verify Stock Decorators

## Description
This plugin contains the stock decorators for the AI Verify report.

## Plugin Content
Widgets
- Divider
- Header 1
- Header 2
- Header 3
- Header 4
- Header 5
- Header 6
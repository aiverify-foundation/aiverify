# Test Engine Core Modules

## Description
* This core modules project provides different serializers, data and models modules 
that can be used by the Test Engine App.

## License
* Licensed under Apache Software License 2.0

## Developers:
* AI Verify
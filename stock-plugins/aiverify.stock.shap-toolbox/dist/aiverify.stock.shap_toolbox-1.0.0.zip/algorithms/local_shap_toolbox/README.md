# Algorithm - local SHAP toolbox

## Description
* local shap algorithm

## License
* Licensed under Apache Software License 2.0

## Developers:
* Example Author

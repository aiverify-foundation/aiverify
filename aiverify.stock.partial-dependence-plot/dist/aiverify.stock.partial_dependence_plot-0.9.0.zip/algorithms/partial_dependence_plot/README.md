# Algorithm - Partial Dependence Plot

## Description
* A Partial Dependence Plot (PDP) explains how each feature and its feature value contribute to the predictions.

## License
* Licensed under Apache Software License 2.0

## Developers:
* AI Verify
